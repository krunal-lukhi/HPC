import os

problem_name = "letshpc_mpi"

os.system("rm /Users/roshani/Desktop/6th_Sem/HPC/Lab5/" + problem_name + "/combined_logs.csv")
os.system("rm /Users/roshani/Desktop/6th_Sem/HPC/Lab5/" + problem_name + "/combined_logs.txt")
os.system("rm /Users/roshani/Desktop/6th_Sem/HPC/Lab5/" + problem_name + "/codes_run_file")
os.system("rm /Users/roshani/Desktop/6th_Sem/HPC/Lab5/" + problem_name + "/all_codes/progress.txt")

os.system("ssh 201601059@10.100.71.130 \"rm -r HPC/Lab4/" + problem_name + "\"")
os.system("scp -r /Users/roshani/Desktop/6th_Sem/HPC/Lab5/" + problem_name + "/ 201601059@10.100.71.130:/home/201601059/HPC/Lab4/")
os.system("ssh -C 201601059@10.100.71.130")
os.system("scp -r 201601059@10.100.71.130:/home/201601059/HPC/Lab4/" + problem_name + "/ /Users/roshani/Desktop/6th_Sem/HPC/Lab5/")

